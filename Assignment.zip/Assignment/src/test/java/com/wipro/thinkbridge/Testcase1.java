package com.wipro.thinkbridge;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Testcase1 {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\chromedriver.exe");

		// initialize the Chrome driver

		WebDriver driver = new ChromeDriver();

		// invoke the browser

		driver.get("http://jt-dev.azurewebsites.net/%23/SignUp");

		// maximize the browser window

		driver.manage().window().maximize();

		// Validate that drop down has English and Dutch

		WebElement DropDown = driver.findElement(By.xpath("(//span[@class='ui-select-match-text pull-left'])[1]"));

		Select select = new Select(DropDown);
		List<WebElement> options = select.getOptions();
		for (WebElement we : options) {
			System.out.println(we.getText());

			if (we.getText().contains("English")) {
				System.out.println("The value is English");
			} else {

				System.out.println("The value is not English");

			}
			
		}

		WebElement FullName = driver.findElement(By.xpath("//input[@id='name']"));

		FullName.sendKeys("Shruti");

		WebElement OrgName = driver.findElement(By.xpath("//input[@id='orgName']"));

		OrgName.sendKeys("Infosys");

		WebElement Email = driver.findElement(By.xpath("//input[@id='singUpEmail']"));

		Email.sendKeys("shruti.aralaguppi@gmail.com");

		WebElement Agree = driver.findElement(By.xpath("//span[contains(text(),'I agree to the')]"));

		Agree.click();

		WebElement getStarted = driver.findElement(By.xpath("//button[contains(text(),'Get Started')]"));

		getStarted.click();
		
		// demo mail tracker is to be configured for this. 

		// locate Demo Inbox and click it
		driver.findElement(By.xpath("//a[@title='Demo inbox']")).click();

		// look for the given text in the list of web elements
		List<WebElement> allMessages = driver
				.findElements(By.xpath("//*[contains(text(), 'Here comes an attachment')]"));

		// check if text has been found or not
		if (allMessages.isEmpty()) {
			System.out.println("Test not passed");
		} else {
			System.out.println("Test passed");
		}

		driver.close();

	}

}
